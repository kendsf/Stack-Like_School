/* User ACTION Type*/
export const SET_USER = 'SET_USER';
export const CLEAR_USER = 'CLEAR_USER';

/* Channel ACTION Type*/

export const SET_CURRENT_CHANNEL = 'SET_CURRENT_CHANNEL';

export const SET_MESSAGE_LIST = 'SET_MESSAGE_LIST';

